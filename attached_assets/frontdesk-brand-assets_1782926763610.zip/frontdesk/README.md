# FrontDesk — Brand Assets

OBTV Studio Security · Guest Management. Dark NOC design language, built to sit
alongside LineDeck, BookStudio, and Frame Control.

## Contents

```
frontdesk-brand.svg              Full brand sheet (logos, palette, type, badge, status system)

logo/
  frontdesk-logo-dark.svg/.png   Primary horizontal logo (on navy)
  frontdesk-logo-light.svg/.png  Logo for light backgrounds

icon/
  frontdesk-icon.svg             Master app icon (512, full detail)
  frontdesk-icon-32.svg          Simplified mark for small sizes
  frontdesk-icon-512.png         App icon / store listing
  frontdesk-icon-192.png         PWA / Android
  frontdesk-icon-180.png         iOS apple-touch-icon
  frontdesk-icon-96/48/32/16.png Favicon / UI sizes
  favicon.ico                    Multi-res favicon (16/32/48)

badge/
  frontdesk-badge-template.svg/.png   Printable visitor badge layout

tokens/
  frontdesk-tokens.css           CSS custom properties
  frontdesk-tokens.json          Design tokens (JSON) incl. status system
```

## The mark
A security counter with a nameplate slot, topped by a signal-teal **presence dot**.
The dot means "checked in / on-site" and carries through the product as the live
status indicator.

## Core colors
| Token        | Hex       | Use                              |
|--------------|-----------|----------------------------------|
| Canvas       | `#0B0E1A` | App background                   |
| Surface      | `#111A2E` | Cards, panels                    |
| Signal Teal  | `#2DD4BF` | Primary accent / on-site status  |
| Accent Blue  | `#3B82F6` | Expected queue                   |
| Overstay     | `#F59E0B` | Past expected departure          |
| Watchlist    | `#EF4444` | Blocklist flag                   |

## Type
- UI: **Inter** (Segoe UI fallback)
- Data / timestamps / badge IDs: **JetBrains Mono**

## Web usage
```html
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="/frontdesk-icon-32.png">
<link rel="apple-touch-icon" href="/frontdesk-icon-180.png">
```
